package BBDD;

import java.sql.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Connection conexion = ConexionBD.conectar();

        if (conexion == null) {
            System.out.println("Error en la conexión a la base de datos. Finalizando el programa.");
            return;
        }

        System.out.println("Bienvenido al sistema.");
        String rol = iniciarSesion(conexion);
        if (rol == null) {
            System.out.println("No se pudo iniciar sesión. Finalizando el programa.");
            return;
        }

        // Llamada al menú correspondiente según el rol
        if (rol.equalsIgnoreCase("Admin")) {
            menuAdministrador(conexion);
        } else if (rol.equalsIgnoreCase("Empleado")) {
            menuEmpleado(conexion);
        } else if (rol.equalsIgnoreCase("Cliente")) {
            menuCliente(conexion);
        } else {
            System.out.println("Rol desconocido. Finalizando el programa.");
        }
    }

    // Método para iniciar sesión
    private static String iniciarSesion(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Alias:");
        String alias = scanner.nextLine();
        System.out.println("Clave:");
        String clave = scanner.nextLine();

        String consulta = "SELECT rol FROM usuario WHERE Alias = ? AND Clave = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(consulta)) {
            stmt.setString(1, alias);
            stmt.setString(2, clave);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("rol");
            } else {
                System.out.println("Credenciales incorrectas.");
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Error en la conexión: " + e.getMessage());
            return null;
        }
    }
    
 // Método para el menú de Empleado
    private static void menuEmpleado(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("\nMenú Empleado:");
            System.out.println("1. Visualizar productos");
            System.out.println("2. Realizar ventas");
            System.out.println("3. Ver tickets generados");
            System.out.println("4. Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            if (opcion == 1) {
                visualizarProductos(conexion); // Mostrar productos con filtros
            } else if (opcion == 2) {
                realizarVenta(conexion, 1); // El empleado tiene código 1
            } else if (opcion == 3) {
                verTicketsGenerados(conexion);
            } else if (opcion == 4) {
                salir = true;
            } else {
                System.out.println("Opción inválida.");
            }
        }
    }

    // Método para visualizar productos con filtros (por inicial, precio, stock)
    private static void visualizarProductos(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Filtrar productos por:");
        System.out.println("1. Inicial");
        System.out.println("2. Precio (ascendente)");
        System.out.println("3. Precio (descendente)");
        System.out.println("4. Stock");
        int filtro = scanner.nextInt();
        scanner.nextLine();

        try {
            String consulta = "";
            if (filtro == 1) {
                System.out.println("Introduce la inicial del producto:");
                String inicial = scanner.nextLine() + "%";
                consulta = "SELECT * FROM producto WHERE Nombre LIKE ? ORDER BY Nombre";
                PreparedStatement stmt = conexion.prepareStatement(consulta);
                stmt.setString(1, inicial);
                mostrarProductos(stmt);
            } else if (filtro == 2) {
                consulta = "SELECT * FROM producto ORDER BY PrecioUnitario ASC";
                PreparedStatement stmt = conexion.prepareStatement(consulta);
                mostrarProductos(stmt);
            } else if (filtro == 3) {
                consulta = "SELECT * FROM producto ORDER BY PrecioUnitario DESC";
                PreparedStatement stmt = conexion.prepareStatement(consulta);
                mostrarProductos(stmt);
            } else if (filtro == 4) {
                consulta = "SELECT * FROM producto ORDER BY Stock DESC";
                PreparedStatement stmt = conexion.prepareStatement(consulta);
                mostrarProductos(stmt);
            } else {
                System.out.println("Filtro inválido.");
            }
        } catch (SQLException e) {
            System.out.println("Error al filtrar productos: " + e.getMessage());
        }
    }

    // Método para mostrar los productos que cumplen el filtro
    private static void mostrarProductos(PreparedStatement stmt) throws SQLException {
        ResultSet rs = stmt.executeQuery();
        if (!rs.isBeforeFirst()) {
            System.out.println("No hay productos que cumplan el filtro.");
            return;
        }

        while (rs.next()) {
            System.out.println("ID: " + rs.getInt("idProducto") +
                    ", Nombre: " + rs.getString("Nombre") +
                    ", Precio: " + rs.getFloat("PrecioUnitario") +
                    ", Stock: " + rs.getInt("Stock"));
        }
    }

    // Método para realizar ventas por parte del empleado
    private static void realizarVenta(Connection conexion, int codigoEmpleado) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Introduce el código o nombre del cliente:");
        String clienteInput = scanner.nextLine();

        try {
            String consultaCliente = "SELECT * FROM cliente WHERE numerodecliente = ? OR Nombre = ?";
            PreparedStatement stmtCliente = conexion.prepareStatement(consultaCliente);
            stmtCliente.setString(1, clienteInput);
            stmtCliente.setString(2, clienteInput);
            ResultSet rsCliente = stmtCliente.executeQuery();

            if (!rsCliente.next()) {
                System.out.println("Cliente no encontrado.");
                return;
            }

            int clienteId = rsCliente.getInt("numerodecliente");

            System.out.println("Introduce el ID del producto:");
            int idProducto = scanner.nextInt();
            System.out.println("Cantidad:");
            int cantidad = scanner.nextInt();

            realizarVentaProducto(conexion, clienteId, idProducto, cantidad, codigoEmpleado);

        } catch (SQLException e) {
            System.out.println("Error al realizar la venta: " + e.getMessage());
        }
    }

    
 // Método para registrar la venta del producto
    private static void realizarVentaProducto(Connection conexion, int clienteId, int idProducto, int cantidad, int codigoEmpleado) {
        try {
            // Consulta el precio y el stock del producto
            String consultaProducto = "SELECT Stock, PrecioUnitario FROM producto WHERE idProducto = ?";
            PreparedStatement stmtProducto = conexion.prepareStatement(consultaProducto);
            stmtProducto.setInt(1, idProducto);
            ResultSet rsProducto = stmtProducto.executeQuery();

            if (!rsProducto.next()) {
                System.out.println("El producto no existe.");
                return;
            }

            int stock = rsProducto.getInt("Stock");
            float precio = rsProducto.getFloat("PrecioUnitario");

            // Verifica si hay suficiente stock
            if (cantidad > stock) {
                System.out.println("Stock insuficiente. Disponible: " + stock);
                return;
            }

            // Calcular el total y los puntos
            float total = cantidad * precio;
            int puntos = (int) (total * 0.1);

            // Inserta un nuevo ticket
            String insertarTicket = "INSERT INTO ticket (PrecioTotal, Empleado_codigoEmpleado, Cliente_numerodecliente) VALUES (?, ?, ?)";
            PreparedStatement stmtVenta = conexion.prepareStatement(insertarTicket);
            stmtVenta.setFloat(1, total);
            stmtVenta.setInt(2, codigoEmpleado);  // El código del empleado
            stmtVenta.setInt(3, clienteId);       // El ID del cliente
            stmtVenta.executeUpdate();

            // Actualiza el stock del producto
            String actualizarStock = "UPDATE producto SET Stock = Stock - ? WHERE idProducto = ?";
            PreparedStatement stmtActualizarStock = conexion.prepareStatement(actualizarStock);
            stmtActualizarStock.setInt(1, cantidad);
            stmtActualizarStock.setInt(2, idProducto);
            stmtActualizarStock.executeUpdate();

            // Actualiza los puntos del cliente
            String actualizarPuntos = "UPDATE usuario SET Puntos = Puntos + ? WHERE Alias = (SELECT Usuario_Alias FROM cliente WHERE numerodecliente = ?)";
            PreparedStatement stmtPuntos = conexion.prepareStatement(actualizarPuntos);
            stmtPuntos.setInt(1, puntos);
            stmtPuntos.setInt(2, clienteId);
            stmtPuntos.executeUpdate();

            // Mensaje de éxito
            System.out.println("Venta registrada correctamente. Total: " + total + "€, Puntos: " + puntos);
        } catch (SQLException e) {
            System.out.println("Error al registrar la venta: " + e.getMessage());
        }
    }


    // Ver los tickets generados por el empleado
    private static void verTicketsGenerados(Connection conexion) {
        try {
            String consulta = "SELECT * FROM ticket WHERE Empleado_codigoEmpleado = ?";
            PreparedStatement stmt = conexion.prepareStatement(consulta);
            stmt.setInt(1, 1); // Cambiar según el código de empleado en sesión
            ResultSet rs = stmt.executeQuery();

            if (!rs.isBeforeFirst()) {
                System.out.println("No hay tickets generados.");
                return;
            }

            while (rs.next()) {
                System.out.println("Ticket ID: " + rs.getInt("idTicket") +
                        ", Total: " + rs.getFloat("PrecioTotal") +
                        ", Cliente ID: " + rs.getInt("Cliente_numerodecliente"));
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar tickets: " + e.getMessage());
        }
    }
 // Método para el menú del Cliente
    private static void menuCliente(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("\nMenú Cliente:");
            System.out.println("1. Visualizar productos");
            System.out.println("2. Realizar compras");
            System.out.println("3. Ver historial de compras");
            System.out.println("4. Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            if (opcion == 1) {
                visualizarProductos(conexion); // Ver productos
            } else if (opcion == 2) {
                realizarVenta(conexion, 1); // Realizar compra con código de empleado = 1
            } else if (opcion == 3) {
                verHistorialCompras(conexion); // Ver historial de compras
            } else if (opcion == 4) {
                salir = true;
            } else {
                System.out.println("Opción inválida.");
            }
        }
    }

    // Ver el historial de compras del cliente
    private static void verHistorialCompras(Connection conexion) {
        try {
            String consulta = "SELECT * FROM ticket WHERE Cliente_numerodecliente = ?";
            PreparedStatement stmt = conexion.prepareStatement(consulta);
            stmt.setInt(1, 1); // Cambiar según ID del cliente
            ResultSet rs = stmt.executeQuery();

            if (!rs.isBeforeFirst()) {
                System.out.println("No hay compras registradas.");
                return;
            }

            while (rs.next()) {
                System.out.println("Ticket ID: " + rs.getInt("idTicket") +
                        ", Total: " + rs.getFloat("PrecioTotal") +
                        ", Empleado ID: " + rs.getInt("Empleado_codigoEmpleado"));
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar historial de compras: " + e.getMessage());
        }
    }


    // Menú para el Administrador
    private static void menuAdministrador(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("\nMenú Administrador:");
            System.out.println("1. Gestionar clientes");
            System.out.println("2. Gestionar empleados");
            System.out.println("3. Gestionar productos");
            System.out.println("4. Ver ventas realizadas");
            System.out.println("5. Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            if (opcion == 1) {
                menuGestionClientes(conexion);
            } else if (opcion == 2) {
                menuGestionEmpleados(conexion);
            } else if (opcion == 3) {
                menuGestionProductos(conexion);
            } else if (opcion == 4) {
                mostrarVentas(conexion);
            } else if (opcion == 5) {
                salir = true;
            } else {
                System.out.println("Opción inválida.");
            }
        }
    }

    // Menú para gestionar clientes
    private static void menuGestionClientes(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("\nGestión de Clientes:");
            System.out.println("1. Insertar cliente");
            System.out.println("2. Modificar cliente");
            System.out.println("3. Eliminar cliente");
            System.out.println("4. Mostrar todos los clientes");
            System.out.println("5. Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            if (opcion == 1) {
                insertarCliente(conexion);
            } else if (opcion == 2) {
                modificarCliente(conexion);
            } else if (opcion == 3) {
                eliminarCliente(conexion);
            } else if (opcion == 4) {
                mostrarClientes(conexion);
            } else if (opcion == 5) {
                salir = true;
            } else {
                System.out.println("Opción inválida.");
            }
        }
    }

    // Método para insertar cliente
    private static void insertarCliente(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el alias del cliente:");
        String alias = scanner.nextLine();
        System.out.println("Introduce la clave del cliente:");
        String clave = scanner.nextLine();
        System.out.println("Introduce el nombre del cliente:");
        String nombre = scanner.nextLine();
        System.out.println("Introduce la dirección del cliente:");
        String direccion = scanner.nextLine();

        try {
            // Insertar en la tabla usuario
            String insertarUsuario = "INSERT INTO usuario (Alias, Clave, Rol, Puntos) VALUES (?, ?, 'Cliente', 0)";
            PreparedStatement stmtUsuario = conexion.prepareStatement(insertarUsuario);
            stmtUsuario.setString(1, alias);
            stmtUsuario.setString(2, clave);
            stmtUsuario.executeUpdate();

            // Insertar en la tabla cliente
            String insertarCliente = "INSERT INTO cliente (Nombre, Direccion, Usuario_Alias) VALUES (?, ?, ?)";
            PreparedStatement stmtCliente = conexion.prepareStatement(insertarCliente);
            stmtCliente.setString(1, nombre);
            stmtCliente.setString(2, direccion);
            stmtCliente.setString(3, alias);
            stmtCliente.executeUpdate();

            System.out.println("Cliente insertado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al insertar cliente: " + e.getMessage());
        }
    }

    // Método para modificar cliente
    private static void modificarCliente(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el código del cliente a modificar:");
        int idCliente = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Introduce el nuevo nombre del cliente:");
        String nuevoNombre = scanner.nextLine();
        System.out.println("Introduce la nueva dirección del cliente:");
        String nuevaDireccion = scanner.nextLine();

        try {
            String modificarCliente = "UPDATE cliente SET Nombre = ?, Direccion = ? WHERE numerodecliente = ?";
            PreparedStatement stmt = conexion.prepareStatement(modificarCliente);
            stmt.setString(1, nuevoNombre);
            stmt.setString(2, nuevaDireccion);
            stmt.setInt(3, idCliente);
            stmt.executeUpdate();

            System.out.println("Cliente modificado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al modificar cliente: " + e.getMessage());
        }
    }

    // Método para eliminar cliente
    private static void eliminarCliente(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el código del cliente a eliminar:");
        int idCliente = scanner.nextInt();

        try {
            String eliminarCliente = "DELETE FROM cliente WHERE numerodecliente = ?";
            PreparedStatement stmt = conexion.prepareStatement(eliminarCliente);
            stmt.setInt(1, idCliente);
            stmt.executeUpdate();

            System.out.println("Cliente eliminado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al eliminar cliente: " + e.getMessage());
        }
    }

    // Mostrar todos los clientes
    private static void mostrarClientes(Connection conexion) {
        try {
            String consultaClientes = "SELECT * FROM cliente";
            PreparedStatement stmt = conexion.prepareStatement(consultaClientes);
            ResultSet rs = stmt.executeQuery();

            if (!rs.isBeforeFirst()) {
                System.out.println("No hay clientes registrados.");
                return;
            }

            while (rs.next()) {
                System.out.println("Código: " + rs.getInt("numerodecliente") +
                        ", Nombre: " + rs.getString("Nombre") +
                        ", Dirección: " + rs.getString("Direccion"));
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar clientes: " + e.getMessage());
        }
    }

    // Método para gestionar empleados
    private static void menuGestionEmpleados(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("\nGestión de Empleados:");
            System.out.println("1. Insertar empleado");
            System.out.println("2. Modificar empleado");
            System.out.println("3. Eliminar empleado");
            System.out.println("4. Mostrar todos los empleados");
            System.out.println("5. Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            if (opcion == 1) {
                insertarEmpleado(conexion);
            } else if (opcion == 2) {
                modificarEmpleado(conexion);
            } else if (opcion == 3) {
                eliminarEmpleado(conexion);
            } else if (opcion == 4) {
                mostrarEmpleados(conexion);
            } else if (opcion == 5) {
                salir = true;
            } else {
                System.out.println("Opción inválida.");
            }
        }
    }

    // Método para insertar empleado
    private static void insertarEmpleado(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el alias del empleado:");
        String alias = scanner.nextLine();
        System.out.println("Introduce la clave del empleado:");
        String clave = scanner.nextLine();
        System.out.println("Introduce el nombre del empleado:");
        String nombre = scanner.nextLine();

        try {
            String insertarUsuario = "INSERT INTO usuario (Alias, Clave, Rol) VALUES (?, ?, 'Empleado')";
            PreparedStatement stmtUsuario = conexion.prepareStatement(insertarUsuario);
            stmtUsuario.setString(1, alias);
            stmtUsuario.setString(2, clave);
            stmtUsuario.executeUpdate();

            String insertarEmpleado = "INSERT INTO empleado (Nombre, Usuario_Alias) VALUES (?, ?)";
            PreparedStatement stmtEmpleado = conexion.prepareStatement(insertarEmpleado);
            stmtEmpleado.setString(1, nombre);
            stmtEmpleado.setString(2, alias);
            stmtEmpleado.executeUpdate();

            System.out.println("Empleado insertado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al insertar empleado: " + e.getMessage());
        }
    }

    // Método para modificar empleado
    private static void modificarEmpleado(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el código del empleado a modificar:");
        int idEmpleado = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Introduce el nuevo nombre del empleado:");
        String nuevoNombre = scanner.nextLine();

        try {
            String modificarEmpleado = "UPDATE empleado SET Nombre = ? WHERE codigoEmpleado = ?";
            PreparedStatement stmt = conexion.prepareStatement(modificarEmpleado);
            stmt.setString(1, nuevoNombre);
            stmt.setInt(2, idEmpleado);
            stmt.executeUpdate();

            System.out.println("Empleado modificado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al modificar empleado: " + e.getMessage());
        }
    }

    // Método para eliminar empleado
    private static void eliminarEmpleado(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el código del empleado a eliminar:");
        int idEmpleado = scanner.nextInt();

        try {
            String eliminarEmpleado = "DELETE FROM empleado WHERE codigoEmpleado = ?";
            PreparedStatement stmt = conexion.prepareStatement(eliminarEmpleado);
            stmt.setInt(1, idEmpleado);
            stmt.executeUpdate();

            System.out.println("Empleado eliminado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al eliminar empleado: " + e.getMessage());
        }
    }

    // Mostrar todos los empleados
    private static void mostrarEmpleados(Connection conexion) {
        try {
            String consultaEmpleados = "SELECT * FROM empleado";
            PreparedStatement stmt = conexion.prepareStatement(consultaEmpleados);
            ResultSet rs = stmt.executeQuery();

            if (!rs.isBeforeFirst()) {
                System.out.println("No hay empleados registrados.");
                return;
            }

            while (rs.next()) {
                System.out.println("Código: " + rs.getInt("codigoEmpleado") +
                        ", Nombre: " + rs.getString("Nombre"));
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar empleados: " + e.getMessage());
        }
    }

    // Método para gestionar productos
    private static void menuGestionProductos(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("\nGestión de Productos:");
            System.out.println("1. Insertar producto");
            System.out.println("2. Modificar producto");
            System.out.println("3. Eliminar producto");
            System.out.println("4. Mostrar todos los productos");
            System.out.println("5. Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            if (opcion == 1) {
                insertarProducto(conexion);
            } else if (opcion == 2) {
                modificarProducto(conexion);
            } else if (opcion == 3) {
                eliminarProducto(conexion);
            } else if (opcion == 4) {
                mostrarProductos(conexion);
            } else if (opcion == 5) {
                salir = true;
            } else {
                System.out.println("Opción inválida.");
            }
        }
    }

    // Método para insertar producto
    private static void insertarProducto(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el nombre del producto:");
        String nombre = scanner.nextLine();
        System.out.println("Introduce el precio del producto:");
        float precio = scanner.nextFloat();
        System.out.println("Introduce el stock del producto:");
        int stock = scanner.nextInt();

        try {
            String insertarProducto = "INSERT INTO producto (Nombre, PrecioUnitario, Stock) VALUES (?, ?, ?)";
            PreparedStatement stmt = conexion.prepareStatement(insertarProducto);
            stmt.setString(1, nombre);
            stmt.setFloat(2, precio);
            stmt.setInt(3, stock);
            stmt.executeUpdate();

            System.out.println("Producto insertado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al insertar producto: " + e.getMessage());
        }
    }

    // Método para modificar producto
    private static void modificarProducto(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el código del producto a modificar:");
        int idProducto = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Introduce el nuevo nombre del producto:");
        String nuevoNombre = scanner.nextLine();
        System.out.println("Introduce el nuevo precio del producto:");
        float nuevoPrecio = scanner.nextFloat();
        System.out.println("Introduce el nuevo stock del producto:");
        int nuevoStock = scanner.nextInt();

        try {
            String modificarProducto = "UPDATE producto SET Nombre = ?, PrecioUnitario = ?, Stock = ? WHERE idProducto = ?";
            PreparedStatement stmt = conexion.prepareStatement(modificarProducto);
            stmt.setString(1, nuevoNombre);
            stmt.setFloat(2, nuevoPrecio);
            stmt.setInt(3, nuevoStock);
            stmt.setInt(4, idProducto);
            stmt.executeUpdate();

            System.out.println("Producto modificado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al modificar producto: " + e.getMessage());
        }
    }

    // Método para eliminar producto
    private static void eliminarProducto(Connection conexion) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el código del producto a eliminar:");
        int idProducto = scanner.nextInt();

        try {
            String eliminarProducto = "DELETE FROM producto WHERE idProducto = ?";
            PreparedStatement stmt = conexion.prepareStatement(eliminarProducto);
            stmt.setInt(1, idProducto);
            stmt.executeUpdate();

            System.out.println("Producto eliminado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al eliminar producto: " + e.getMessage());
        }
    }

    // Mostrar todos los productos
    private static void mostrarProductos(Connection conexion) {
        try {
            String consultaProductos = "SELECT * FROM producto";
            PreparedStatement stmt = conexion.prepareStatement(consultaProductos);
            ResultSet rs = stmt.executeQuery();

            if (!rs.isBeforeFirst()) {
                System.out.println("No hay productos registrados.");
                return;
            }

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("idProducto") +
                        ", Nombre: " + rs.getString("Nombre") +
                        ", Precio: " + rs.getFloat("PrecioUnitario") +
                        ", Stock: " + rs.getInt("Stock"));
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar productos: " + e.getMessage());
        }
    }

    // Mostrar ventas realizadas
    private static void mostrarVentas(Connection conexion) {
        try {
            String consultaVentas = "SELECT t.idTicket, t.PrecioTotal, e.Nombre AS Empleado, c.Nombre AS Cliente " +
                    "FROM ticket t " +
                    "JOIN empleado e ON t.Empleado_codigoEmpleado = e.codigoEmpleado " +
                    "JOIN cliente c ON t.Cliente_numerodecliente = c.numerodecliente";
            PreparedStatement stmt = conexion.prepareStatement(consultaVentas);
            ResultSet rs = stmt.executeQuery();

            if (!rs.isBeforeFirst()) {
                System.out.println("No hay ventas registradas.");
                return;
            }

            while (rs.next()) {
                System.out.println("Ticket ID: " + rs.getInt("idTicket") +
                        ", Total: " + rs.getDouble("PrecioTotal") +
                        ", Empleado: " + rs.getString("Empleado") +
                        ", Cliente: " + rs.getString("Cliente"));
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar ventas: " + e.getMessage());
        }
    }
}
