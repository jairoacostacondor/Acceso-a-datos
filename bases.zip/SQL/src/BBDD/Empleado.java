package BBDD;

public class Empleado extends Usuario {
    public Empleado(String alias, String clave, String rol, int puntos) {
        super(alias, clave, rol, puntos);
    }
}
