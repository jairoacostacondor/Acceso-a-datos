package BBDD;

public class Ticket {
    private int idTicket;
    private int empleadoId;
    private int clienteId;
    private float total;
    private int puntos;

    public Ticket(int idTicket, int empleadoId, int clienteId, float total, int puntos) {
        this.idTicket = idTicket;
        this.empleadoId = empleadoId;
        this.clienteId = clienteId;
        this.total = total;
        this.puntos = puntos;
    }

    // Getters y setters
    public int getIdTicket() {
        return idTicket;
    }

    public void setIdTicket(int idTicket) {
        this.idTicket = idTicket;
    }

    public int getEmpleadoId() {
        return empleadoId;
    }

    public void setEmpleadoId(int empleadoId) {
        this.empleadoId = empleadoId;
    }

    public int getClienteId() {
        return clienteId;
    }

    public void setClienteId(int clienteId) {
        this.clienteId = clienteId;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }
}
