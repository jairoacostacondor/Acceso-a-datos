package BBDD;

public class Cliente extends Usuario {
    private String direccion;

    public Cliente(String alias, String clave, String rol, int puntos, String direccion) {
        super(alias, clave, rol, puntos);
        this.direccion = direccion;
    }

    // Getters y setters
    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}