package BBDD;

public class CantidadProducto {
    private int idTicket;
    private int idProducto;
    private int cantidad;

    public CantidadProducto(int idTicket, int idProducto, int cantidad) {
        this.idTicket = idTicket;
        this.idProducto = idProducto;
        this.cantidad = cantidad;
    }

    // Getters y setters
    public int getIdTicket() {
        return idTicket;
    }

    public void setIdTicket(int idTicket) {
        this.idTicket = idTicket;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}
