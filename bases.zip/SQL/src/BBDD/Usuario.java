package BBDD;

public class Usuario {
    private String alias;
    private String clave;
    private String rol;
    private int puntos;

    public Usuario(String alias, String clave, String rol, int puntos) {
        this.alias = alias;
        this.clave = clave;
        this.rol = rol;
        this.puntos = puntos;
    }

    // Getters y setters
    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }
}